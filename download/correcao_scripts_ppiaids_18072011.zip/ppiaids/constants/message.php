<?php
define("EXPORT_NOTFOUND",     "N�o existe nenhuma ocorr�cia para esse tema");
define("EXPORT_SUCCESS",     "Arquivo exportado com sucesso");
?>