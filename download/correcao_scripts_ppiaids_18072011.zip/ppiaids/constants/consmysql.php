<?php
define("MYSQL_TEST_HOST",     "<nome do host>");
define("MYSQL_TEST_DATABASE",     "<nome do BD>");
define("MYSQL_TEST_USERNAME",     "<nome do usuario do BD>");
define("MYSQL_TEST_PASSWORD",     "<senha do usu�rio do BD");
define("MYSQL_TEST_PORT",     "3306");

define("MYSQL_PRODUCTION_HOST",     "<nome do host>");
define("MYSQL_PRODUCTION_DATABASE", "<nome do BD");
define("MYSQL_PRODUCTION_USERNAME",  "<nome do usuario do BD>");
define("MYSQL_PRODUCTION_PASSWORD",     "<senha do usu�rio do BD>");
define("MYSQL_PRODUCTION_PORT","3306");

?>