﻿<?php include 'incs/cabecalho.php'; ?>
<div id="wrapper">

<div id="menu"><br />
	<?php include 'incs/menu.php'; ?>
</div>

<div id="conteudo"><br />
	<p class="tit"><?php echo htmlentities("Documentos T�cnicos");?></p>
	<p class="textos">
  <b><?php echo htmlentities("Projeto");?></b><br />
  Documentos técnicos sobre o projeto<br/><br/>
  <ul class="doc_tec">
      <li><a href="pdf/sobreprojeto.pdf" target="_blank"><b><?php echo htmlentities("Construindo uma Matriz de Vulnerabilidade para a identifica��o de grupos populacionais priorit�rios no estado de S�o Paulo: etapa para implementa��o de pol�tica de preven��o para DST, HIV e aids");?></b></a><br/><br/></li>
       <li><a href="pdf/baseindicadoresmunicipais.pdf" target="_blank"><b>Lista de Indicadores Municipais</b></a></li>
  </p>
</div>

</div>
<?php include 'incs/rodape.php'; ?> 