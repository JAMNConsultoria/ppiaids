<?php
header("location:view/");
?>