<?php header("Content-Type: text/html; charset=iso-8859-1");?>
<?php include 'incs/cabecalho.php'; ?>            
<div id="wrapper">

	<div id="menu"><br />
        <?php include 'incs/menu.php'; ?>
    </div>
    
    <div id="conteudo"><br />
    	<p class="tit">Ficha Institucional</p>

        <p class="textos">
         <ul class="ficha_tec">
              <li><b>Secret�rio Estadual de Sa�de</b></li>
              <li>Giovanni Guido Cerri</li>
         </ul><br/>
         <ul class="ficha_tec">
              <li><b>Coordenadoria de Controle de Doen�as</b></li>
              <li>Alice Tiago de Souza</li>
        </ul><br/>
        <ul class="ficha_tec">
              <li><b>Coordena��o Estadual de DST/aids</b></li>
                    <li>Maria Clara Gianna Garcia Ribeiro</li>
                    <li>Artur Olhovetchi  Kalichman</li>
        </ul><br/>
        <ul class="ficha_tec">
              <li><b>Ger�ncia de Vigil�ncia Epidemiol�gica</b></li>
                    <li>�ngela Tayra</li>
        </ul><br/>      
        <br /><br />
            
    </div>

</div>    
<?php include 'incs/rodape.php'; ?> 