<link rel="stylesheet" type="text/css" href="css/barra.css" />
<script type="text/javascript" src="js/barra.js"></script>
<div id="barrasp_global">
   <!--  <img src="/barra-gov/barrasp_bg.gif" width="100%" height="50px">-->
   <div id="barrasp_nav">
      <ul>
	     <li><a href="http://www.saopaulo.sp.gov.br/" target="_blank">Portal do Governo</a></li>
		 <li><a href="http://www.cidadao.sp.gov.br/" target="_blank">Cidad&atilde;o.SP</a></li>

		 <li><a href="http://www.investimentos.sp.gov.br/" target="_blank">Investimentos.SP</a></li>
	  </ul>
	  <form action="http://www.saopaulo.sp.gov/barrasp/js/selectbox_goto.php" method="post" onsubmit="return send(this)">
	  <fieldset>
	  <p>
	  <label for="selectbox_goto">Destaques:</label>
	  <select name="selectbox_goto" id="selectbox_goto">
	     <option value="null">Destaques:</option>

		 <option value="http://www.saopaulo.sp.gov.br/sis/noticias.asp">SP Not&iacute;cias</option>
		 <option value="http://www.poupatempo.sp.gov.br/">Poupatempo</option>
		 <option value="http://www.acessasaopaulo.sp.gov.br/">Acessa S&atilde;o Paulo</option>
		 <option value="http://www.e-negociospublicos.com.br/">Licita&ccedil;&otilde;es</option>
		 <option value="null">---------------------------------</option>

		 <option value="null">Secretarias:</option>
		 <option value="http://www.sap.sp.gov.br/">- Administra&ccedil;&atilde;o Penitenci&aacute;ria</option>
		 <option value="http://www.agricultura.sp.gov.br/">- Agricultura e Abastecimento</option>
		 <option value="http://www.desenvolvimentosocial.sp.gov.br/">- Assist&ecirc;ncia e Desenvolvimento Social</option>
		 <option value="http://www.casacivil.sp.gov.br/">- Casa Civil</option>

		 <option value="http://www.casamilitar.sp.gov.br/">- Casa Militar</option>
		 <option value="http://www.saopaulo.sp.gov.br/linha/sec_comunic.htm">- Comunica&ccedil;&atilde;o</option>
		 <option value="http://www.cultura.sp.gov.br/">- Cultura</option>
		 <option value="http://www.desenvolvimento.sp.gov.br/">- Desenvolvimento</option>
		 <option value="http://www.planejamento.sp.gov.br/">- Economia e Planejamento</option>
		 <option value="http://www.educacao.sp.gov.br/">- Educa&ccedil;&atilde;o</option>

		 <option value="http://www.emprego.sp.gov.br/">- Emprego e Rela&ccedil;&otilde;es do Trabalho</option>
		 <option value="http://www.saopaulo.sp.gov.br/linha/sec_ensinosup.htm">- Ensino Superior</option>
		 <option value="http://www.sejel.sp.gov.br/">- Esporte, Lazer e Turismo</option>
		 <option value="http://www.fazenda.sp.gov.br/">- Fazenda</option>
		 <option value="http://www.saopaulo.sp.gov.br/linha/sec_gestao.htm">- Gest&atilde;o P&uacute;blica</option>

		 <option value="http://www.habitacao.sp.gov.br/">- Habita&ccedil;&atilde;o</option>
		 <option value="http://www.justica.sp.gov.br/">- Justi&ccedil;a e Defesa da Cidadania</option>
		 <option value="http://www.ambiente.sp.gov.br/">- Meio Ambiente</option>
		 <option value="http://www.pge.sp.gov.br/">- Procuradoria Geral do Estado</option>
		 <option value="http://www.saopaulo.sp.gov.br/linha/sec_rel_inst.htm">- Rela&ccedil;&otilde;es Institucionais</option>

		 <option value="http://www.energia.sp.gov.br/">- Saneamento e Energia</option>
		 <option value="http://www.saude.sp.gov.br/">- Sa&uacute;de</option>
		 <option value="http://www.ssp.sp.gov.br/">- Seguran&ccedil;a P&uacute;blica</option>
		 <option value="http://www.transportes.sp.gov.br/">- Transportes</option>
		 <option value="http://www.stm.sp.gov.br/">- Transportes Metropolitanos</option>

	  </select><input type="submit" class="inputSubmit" value="OK" />
	  </p>
	  </fieldset>
	  </form>
	  <h1 id="barrasp_logo">
	     <a href="http://www.saopaulo.sp.gov.br/" target="_blank" title="Governo do Estado de S&atilde;o Paulo">Portal do Governo do Estado de S&atilde;o Paulo</a>
	  </h1>
  </div>

</div>