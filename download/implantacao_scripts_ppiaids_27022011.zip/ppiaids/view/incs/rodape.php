<div id="wrapper">
	<div id="rodape">
	<table cellpadding="0" cellspacing="0" border="0" width="100%">
  	<tr>
        <td  align="left"><SUP>Apoio: <a href="http://www.fapesp.br/" target="_blank"><img alt="Funda��o de Amparo � Pesquisa do Estado de S�o Paulo" title="Funda��o de Amparo � Pesquisa do Estado de S�o Paulo" src="img/logo_fapesp.gif" /></a></td>
     	<td  align="left"><a href="http://www.opas.org.br/" target="_blank"><img alt="Organiza��o Pan-Americana da Sa�de site" title="Organiza��o Pan-Americana da Sa�de" src="img/logo_opas.gif" /></a></td>
        <td  align="left"><a href="http://www.cealag.com.br/" target="_blank"><img alt=" Centro de Estudos Augusto Leopoldo Ayrosa Galv�o site" title=" Centro de Estudos Augusto Leopoldo Ayrosa Galv�o" src="img/logo_cealag.gif" /></a></td>
        <td  align="left"><a href="http://www.cnpq.br/" target="_blank"><img alt=" Conselho Nacional de Desenvolvimento Cient�fico e Tecnol�gico site" title=" Conselho Nacional de Desenvolvimento Cient�fico e Tecnol�gico" src="img/logo_cnpq.gif" /></a></td>
    </tr>
  </table>
	</div>

</div>

</div>

</body>
</html>
    
