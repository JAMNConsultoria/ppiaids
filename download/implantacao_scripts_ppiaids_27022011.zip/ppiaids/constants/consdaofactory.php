<?php

define("MYSQL",     "1");
define("SQLSERVER",    "2");

define("MODE_TEST",     "1");
define("MODE_PRODUCTION",    "2");

?>