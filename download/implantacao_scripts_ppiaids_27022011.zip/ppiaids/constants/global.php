<?php

define("VERSION",  "V 1.0");
define("GVE",	"Grupo de Vigil�ncia Epidemiol�gica - GVE");
define("DRS",	"Departamento Regional de Sa�de - DRS");
define("MACRO_REG",  "Macro-regi�o");
define("MUNICIPIO",  "Munic�pio");
define("GRUPO",  "Grupo da Tipologia");
define("COLEGIADO","Colegiado");
define("EXCEL",1);
define("CSV",2);
define("JSON",3);
define("HTML",4);
define("XML",5);

?>